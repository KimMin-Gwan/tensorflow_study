from flask import Flask, render_template, request, url_for
from random import SystemRandom
import jwt
import json

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
    

@app.route('/create_token', methods=['GET', 'POST'])
def create_token():
    if request.method == 'POST':
        username = request.form['username']
        payload = f'{{"admin": "False", "username":\"{username}\"}}'
        token = jwt.encode(json.loads(payload), SECRET_KEY, algorithm="HS256")

        return {"result":"success", 'token':token}
        
    return render_template('create_token.html')


@app.route('/auth', methods=['GET', 'POST'])
def auth():
    if request.method == 'POST':
        token = request.form['token']
        try:
            decoded = jwt.decode(token, SECRET_KEY, algorithms="HS256")
        except Exception as e:
            return {"error":str(e)}

        if "username" in decoded:
            msg = f"Hello {decoded['username']}."
            if decoded["username"] == "admin":
                if decoded["admin"] == "True":
                    with open("flag.txt", "r") as f:
                        return {"response":f"{msg}. this is flag {f.read()}"}
                return {"error":"you are not admin :("}
            return {"response":msg}
        return {"error":":("}

    return render_template('auth.html')


if __name__ == "__main__":
    rng = SystemRandom
    SECRET_KEY = rng.randbytes(256, 16)
    app.run(host="127.0.0.1", port="5000")
